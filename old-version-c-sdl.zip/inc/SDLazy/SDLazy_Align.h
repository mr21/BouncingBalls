#ifndef		SDLAZY_ALIGN
# define	SDLAZY_ALIGN

# define	ALIGN_CENTER    0
# define	ALIGN_LEFT      1
# define	ALIGN_RIGHT     2
# define	ALIGN_TOP       4
# define	ALIGN_BOTTOM    8

#endif
